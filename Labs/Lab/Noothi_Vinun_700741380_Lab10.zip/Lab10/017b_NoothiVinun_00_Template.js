
/* Noothi Vinun , 2022.10.29, Lab10*/
window.addEventListener( "load", start, false );

function start(){
    console.log("event starting...")
}