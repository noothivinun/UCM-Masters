/* Vinun_Noothi 2022.10.22, Lab09 */
window.addEventListener( "load", start, false );

function start(){
    console.log("event starting...")
}